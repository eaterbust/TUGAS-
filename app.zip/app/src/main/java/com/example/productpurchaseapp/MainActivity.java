package com.example.productpurchaseapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerViewProducts;
    private ProductAdapter productAdapter;
    private List<product> productList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerViewProducts = findViewById(R.id.recyclerViewProducts);
        recyclerViewProducts.setLayoutManager(new LinearLayoutManager(this));

        productList = new ArrayList<>();
        productList.add(new product("Laptop", 1000, R.drawable.ic_launcher_foreground));
        productList.add(new product("Smartphone", 800, R.drawable.ic_launcher_foreground));
        productList.add(new product("Headphone", 100, R.drawable.ic_launcher_foreground));

        productAdapter = new ProductAdapter(this, productList, product -> {
            Toast.makeText(this, product.getName() + " added to cart!", Toast.LENGTH_SHORT).show();
        });

        recyclerViewProducts.setAdapter(productAdapter);
    }
}
